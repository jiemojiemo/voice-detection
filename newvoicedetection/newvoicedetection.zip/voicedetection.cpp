#include "voicedetection.h"

#define MAX(x,y) ( (x)>(y)?(x):(y) )
#define MIN(x,y) ( (x)<(y)?(x):(y) )

CVoiceDetection::CVoiceDetection()
{
	m_winSize = 256;
	m_hop = 90;
	m_ampMaxThreshold = 10;
	m_ampMinThreshold = 2;
	m_zcMaxThreshold = 10;
	m_zcMinThreshold = 5;

	m_minSilence = 30;
	m_minVoice = 100;
	m_voiceCount = 0;
	m_silenceCount = 0;

	m_status=0;
	m_start = 0;
	m_end = 0;

	m_frameCount = 0;
	m_frameData = NULL;
}
CVoiceDetection::~CVoiceDetection()
{
	if( m_frameData != NULL )
		for( int i = 0; i < m_frameCount; ++i )
		{
			if( m_frameData[i] != NULL )
				delete [] m_frameData[i];
		}
}
map<int,int> CVoiceDetection::Detection( const float* buffer, int sampleCount )
{
    //map<int, int> startEndMap;
    EnFrame( buffer, sampleCount, m_winSize, m_hop );
    CalcZeroCrossRate();
    CalcAmplitude();
	CalcAmpThreshold();
    return StartEndPointDetection();
}
void CVoiceDetection::EnFrame( const float* dataIn, int sampleSize, int winSize, int hop )
{
	m_frameCount = (sampleSize - winSize)/hop + 1;
	m_frameData = new float*[ m_frameCount ];
	//auto dataOut = std::shared_ptr<float>( new float*[row] );
	for( int i = 0; i < m_frameCount; ++i )
	{
		m_frameData[i] = new float[winSize];
		if( m_frameData[i] != NULL )
			memcpy( m_frameData[i], (dataIn + i * hop), winSize*sizeof(float) );
	}
}
void CVoiceDetection::CalcZeroCrossRate()
{

    for( int i = 0; i < m_frameCount; ++i )
	{
		int count = 0;
		for( int j = 0; j < m_winSize -1; ++j )
		{
			if( m_frameData[i][j] * m_frameData[i][j + 1] < 0 && m_frameData[i][j] - m_frameData[i][j + 1] > 0.0002)
				count++;
		}
		m_zeroCrossRate.push_back( count );
	}
}
void CVoiceDetection::CalcAmplitude()
{
	for( int i = 0; i < m_frameCount; ++i )
	{
		double ampSum = 0;
		for( int j = 0; j < m_winSize -1; ++j )
		{
			ampSum += m_frameData[i][j] * m_frameData[i][j];
		}
		m_amplitude.push_back( ampSum );
	}
}
void CVoiceDetection::CalcAmpThreshold()
{
    double ampMax = GetAmplitudesMax();
    double ampMin = GetAmplitudesMin();
    m_ampMaxThreshold = ampMax/8.0;
    m_ampMinThreshold = ampMin*100;
}

double CVoiceDetection::GetAmplitudesMax()
{
    double maxAmp = 0.0;
    for( int i = 0; i < m_frameCount; ++i )
	{
		int count = 0;
		double ampSum = 0;
		for( int j = 0; j < m_winSize -1; ++j )
		{
			ampSum += m_frameData[i][j] * m_frameData[i][j];
		}
		if( ampSum > maxAmp )
			maxAmp = ampSum;
	}
	return maxAmp;
}
double CVoiceDetection::GetAmplitudesMin()
{
    double minAmp = 10000.0;
    for( int i = 0; i < m_frameCount; ++i )
	{
		int count = 0;
		double ampSum = 0;
		for( int j = 0; j < m_winSize -1; ++j )
		{
			ampSum += m_frameData[i][j] * m_frameData[i][j];
		}
		if( ampSum < minAmp )
			minAmp = ampSum;
	}
	return minAmp;
}
map<int, int> CVoiceDetection::StartEndPointDetection()
{
    int status = 0;
    int start = 0;
    int end = 0;
    int voiceCount = 0;
    int silenceCount = 0;
    map<int, int> startEndMap;
    VoiceStatus voiceStatus = NOTVOICE;
    for( int i = 0; i < m_frameCount; ++i )
	{
	    voiceStatus = GetVoiceStatus( m_amplitude[i], m_zeroCrossRate[i] );
		switch (status)
		{
		case 0:
		case 1:
			if ( voiceStatus == ISVOICE )
			{
				start = MAX( ( i - voiceCount -1 ),1 );
				status = 2;
				silenceCount = 0;
				voiceCount++;
			}
			else if( voiceStatus == MAYBEVOICE )  //����������
			{
				status = 1;
				voiceCount++;
			}
			else
			{
				status = 0;
				voiceCount = 0;
			}
			break;
		case 2:
			if( voiceStatus == STILLVOICE )
				voiceCount++;
			else
			{
				silenceCount++;
				if( silenceCount < m_minSilence )
					voiceCount++;
				else if( voiceCount < m_minVoice )
				{
					status = 0;
					silenceCount = 0;
					voiceCount = 0;
				}
				else
					status = 3;
			}
			break;
		case 3:
			voiceCount = voiceCount - silenceCount/2;
			end = start + voiceCount - 1;
			startEndMap.insert( pair<int,int>( start, end ) );
			status = 0;
			silenceCount = 0;
			voiceCount = 0;
			break;
		}
	}
	return startEndMap;
}

CVoiceDetection::VoiceStatus CVoiceDetection::GetVoiceStatus( double amp, int zcr )
{
    if( amp > m_ampMaxThreshold || (amp > m_ampMinThreshold && zcr < m_zcMinThreshold) )
        return ISVOICE;
    if( amp > m_ampMinThreshold || zcr < m_zcMaxThreshold )
        return MAYBEVOICE;
    if( amp > m_ampMinThreshold || zcr < m_zcMinThreshold )
        return STILLVOICE;
    return NOTVOICE;
}









