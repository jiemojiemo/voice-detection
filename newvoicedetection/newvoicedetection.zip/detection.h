#pragma once

float** EnFrame( float* dataIn, int sampleSize, int winSize, int hop );